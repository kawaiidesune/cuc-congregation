<?php // Opening PHP tag - nothing should be before this, not even whitespace
?>